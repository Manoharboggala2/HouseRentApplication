import React from 'react'
import '../App.css';
function Footer() {
  return (
    <div>
        <small className='footer'> &copy; All Right Reserved - 2025</small>
    </div>
  )
}

export default Footer
